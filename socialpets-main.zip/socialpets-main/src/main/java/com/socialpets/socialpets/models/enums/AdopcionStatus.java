package com.socialpets.socialpets.models.enums;

public enum AdopcionStatus {
    EN_ESTUDIO,
    APROBADA,
    RECHAZADA,
    
}
